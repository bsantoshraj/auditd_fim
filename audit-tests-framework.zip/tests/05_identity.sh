#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

TEST_USER="auditd_test_user"
TEST_GROUP="auditd_test_group"

run_test "Group add" "identity.groupadd" "groupadd $TEST_GROUP"
run_test "User add" "identity.useradd" "useradd -g $TEST_GROUP $TEST_USER"
run_test "User mod" "identity.usermod" "usermod -aG sudo $TEST_USER"
run_test "Password change" "identity.passwd" "echo '$TEST_USER:Test123!' | chpasswd"
run_test "User delete" "identity.userdel" "userdel $TEST_USER"
run_test "Group delete" "identity.groupdel" "groupdel $TEST_GROUP"
